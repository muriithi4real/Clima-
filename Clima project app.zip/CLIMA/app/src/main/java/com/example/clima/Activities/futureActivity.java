package com.example.clima.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.clima.Adapters.futureAdapter;
import com.example.clima.Domains.FutureDomain;
import com.example.clima.R;

import java.util.ArrayList;

public class futureActivity extends AppCompatActivity {
    private RecyclerView.Adapter adapterTommorow;
    public  RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_future);

        initRecyclerview();
        setVariable();
    }

    private void setVariable() {
        ConstraintLayout backbtn= findViewById(R.id.backbtn);
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(futureActivity.this, MainActivity.class));
            }
        });
    }


    private void initRecyclerview() {
        ArrayList<FutureDomain> items=new ArrayList<>();

        items.add(new FutureDomain("Sat","Stormy","storm",25,10));
        items.add(new FutureDomain("Sun","Cloudy","cloudy",24,16));
        items.add(new FutureDomain("Mon","Windy","Windy",27,17));
        items.add(new FutureDomain("Tue","Sunny","Cloudy-sunny",23,15));
        items.add(new FutureDomain("Wed","cloudy-sunny","sunny",24,17));
        items.add(new FutureDomain("Thu","rain","rainy",25,13));

        recyclerView=findViewById(R.id.vieww2);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));

        adapterTommorow=new futureAdapter(items);
        recyclerView.setAdapter(adapterTommorow);
    }
}